## React Frontend for smooth User Experience.

### Install the dependencies from package.json

- Install node dependencies from package.json by heading to /L6_Frontend/ :
```bash
$ npm install
```

- Starting node server :
```bash
$ npm run start
```